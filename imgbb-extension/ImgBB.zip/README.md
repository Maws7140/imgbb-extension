# ImgBB Uploader

Simple extension to right-click upload images to ImgBB.

## Usage
1. Load unpacked in `chrome://extensions`.
2. Click icon, paste API key from [api.imgbb.com](https://api.imgbb.com/).
3. Right-click images -> Upload.

Features:
- Auto-copy link or BB code
- Auto-delete timer
- Local history

MIT.